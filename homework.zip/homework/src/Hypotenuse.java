public class Hypotenuse {
    //inside the class inside the method
    //a=3,b=4,where a and b are sides of right angle triangle
    //c=hypotenuse value
    public static void main(String[]args){
        double a=3, b=4;
        double c=(a*a)+(b*b);
        c= Math.sqrt(c);
        System.out.println(c);


    }
}
