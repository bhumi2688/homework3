public class Percentage {
    //inside the class outside the method
    // subjects (B1)History=60,(B2)English=70,(B3)Geography=85
    //calculating total percentange=(total/(total subjects*100)*100))*100
    //Average=total/total subjects
public static void main(String[]args) {


    int history = 60;
    int english = 70;
    int geography = 85;
    int total = (history + english + geography);
    int percentage=(total/3);

    System.out.println(total);
    System.out.println(percentage);



}












}
