public class Area {
    //inside the class inside the method with  keyword
    //pie=3.14 r=12 radius of circle


    public static void main(String[]args){
        int radius=12;
        double area=Math.PI*radius*radius;

        System.out.println("Area of a circle=" + area );


    }






}










