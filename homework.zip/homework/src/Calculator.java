public class Calculator {
    //inside the class-outside the method with static keyword
    static int a = 15; //static or class variable
    static int b = 5;
    int ans;
    //This method will perform addition
    static void add(){ // no return type no argument user defined method
        System.out.println(a+b);
    }
    static void sub() {// no return type no argument user defined method
       System.out.println(a-b);
         }
         static void multiply() {// no return type no argument user defined method
        System.out.println(a*b);
         }
         static void divide() {//no return type no argument user defined method
        System.out.println(a/b);
         }
         //Java main method
    public static void main(String[]args){
        add();
        sub();
        multiply();
        divide();
    }

}

