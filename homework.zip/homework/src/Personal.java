public class Personal {
    //inside the class outside the method with static keyword
    String name = "Maria";
    String surname = "Ling";
    String Address = "Chestnut Grove 18 ha0 2lx";
     String dob="02/06/1988";
    int age = 30;

    static void name() {
        System.out.println("Maria");
    }

    static void surname() {
        System.out.println("Ling");
    }

    static void address() {
        System.out.println("Chestnut Grove 18 ha0 2lx");
    }

    static void dob() {
        System.out.println("02/06/1988");
    }

    static void age() {
        System.out.println(30);
    }

    //Java main method
    public static void main(String[] args) {
        name();
        surname();
        address();
        dob();
        age();
    }
}
